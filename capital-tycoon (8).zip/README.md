# Capital Tycoon

## Description
Business clicker simulator with synergies, stocks and luxury items.

## Mechanics
- **Businesses**: 20+ types with upgrades up to level 55
- **Synergies**: Combo bonuses when buying related businesses
- **Breeding**: Paid creation of new businesses from existing ones
- **Stocks**: Random market with volatility
- **Luxury**: 7 items with global bonuses

## Files
- `index.html` — main page
- `game.js` — game logic
- `manifest.json` — PWA manifest
- `icon-*.svg` — SVG icons (convert to PNG for PWA)
- `cover.jpg` — cover image (add manually)

## SVG Icons
All game icons are inline SVG — no emojis, no external dependencies.
